package main

func main() {
	println("Hello, Go!")
}
