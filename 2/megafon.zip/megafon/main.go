package main

func main() {
	amount := 666
	WelcomeBonuce := 5
	bonus := amount/5 + WelcomeBonuce
	println(bonus)
}
