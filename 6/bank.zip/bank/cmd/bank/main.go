package main

import (
	"bank/pkg/bank/card"
	"fmt"
)

func main() {

	fmt.Println(card.IssueCard("TJS", "White", "Infinity"))

}
