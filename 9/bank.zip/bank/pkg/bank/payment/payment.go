package payment

import "bank/pkg/bank/types"

func Max(cardfs []types.Payment) types.Payment{
	mx:= cardfs[0].Amount
	pymnt := types.Payment{}
	for _, i := range cardfs{
		if (i.Amount>mx) {
			mx=i.Amount
			pymnt = i
		}
	}
	return pymnt
}
func PaymentSources(cards []types.Card) []types.PaymentSource {
	var cards1 [] types.PaymentSource
	var temp types.PaymentSource

	for _, i := range cards {

		if i.Balance>0 && i.Active{
			temp = types.PaymentSource{
				Balance : i.Balance,
				Number : string(i.PAN),
				Type : i.Name,
			}
			cards1= append(cards1, temp)
		}
		
	}
	return cards1
	
   }
   