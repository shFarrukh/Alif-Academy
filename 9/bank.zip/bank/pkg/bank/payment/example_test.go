package payment
import (
	"fmt"
	"bank/pkg/bank/types"

)
func ExamplePaymentSources(){
	slice  := [] types.Card{
		{
			PAN:      "5058 xxxx xxxx 0001",
			ID : 1,
			Balance : 10_000_00,
			Active :  true,
			Name: "card1",
		},
		{
			PAN:      "5058 xxxx xxxx 0002",
			ID : 2,
			Balance : -11_000_00,
			Active :  true,
			Name: "card2",
		},
		{
			PAN:      "5058 xxxx xxxx 0003",
			ID : 3,
			Balance : 12_000_00,
			Active :  false,
			Name: "card3",
		},
	} 
	result := PaymentSources(slice)
	for _, i := range result{

		fmt.Println(i.Balance,)
	}
	// Output
	// 5058 xxxx xxxx 0001



	

	
}