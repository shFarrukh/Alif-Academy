package transfer

//reurns the total
func Total(amount int) int {
	return amount + (amount/1000)*5
}
