package main

func main() {
	amount := 100.0
	sellRate := 0.1470
	result := amount / sellRate
	println(result)
}
